public class Bokor {
    private String fajta;
    private int forma;
    private double suruseg;

    public Bokor(String fajta, double suruseg){
        this.fajta = fajta;
        if(suruseg >= 0 && suruseg <= 100){
                this.suruseg = suruseg;
        }
        else if(suruseg < 0){
            this.suruseg = 0;
        }
        else if(suruseg > 100){
            this.suruseg = 100;
        }
    }

    public void nyiras(SovenyvagoOllo ollo){
        if(ollo.vag(suruseg) == true){
            forma = 2;
        }
    }

    public void setSuruseg(double suruseg) {
        if(suruseg < 0){
            suruseg = 0;
        if(suruseg > 100){
            suruseg = 100;
        }
        this.suruseg = suruseg;
        }
    }

    public String forma(){
        if(forma >= 0 && forma <= 4){
            if(forma == 0){
                return "cserje";
            }
            if(forma == 1){
                return "bokor";
            }
            if(forma == 2){
                return "formara nyirt";
            }
            if(forma == 3){
                return "kisse elburjanzott";
            }
            if(forma == 4){
                return "teljesen elburjanzott";
            }
        }
        return "";
    }

    public double getSuruseg() {
        return suruseg;
    }

    public void novekedes(){
        setForma(this.forma + 1);
    }

    public String getFajta() {
        return fajta;
    }

    public void setForma(int forma) {
        if(forma >= 0 && forma <= 4){
            this.forma = forma;
        }
    }

    public void setFajta(String ujFajta) {
        this.fajta = ujFajta;
    }


}
